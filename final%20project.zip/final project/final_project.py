#this application is for entertainment places in the eastern province where the user interacts with application by choosing cities and places
from tkinter import *
class UserData:
    def __init__(self, username, birthyear):
        self.username = username
        self.birthyear = int(birthyear)  # Ensure birthyear is an integer
        self.age = 2024 - self.birthyear
def user_list(users_list):
    # Create a new window to display all users
    user_window = Toplevel()
    user_window.geometry('400x400')
    user_window.title('All Users')
    # Display users in the new window using labels
    y_position = 20  # Start at the top of the window
    for user in users_list:
        user_label = Label(user_window, text=f"Username: {user.username}, Age: {user.age}", font='times')
        user_label.place(x=20, y=y_position)
        y_position += 30  # Move down for the next user
    # Button to close the user window
    close_button = Button(user_window, text="Close", command=user_window.destroy)
    close_button.place(x=150, y=y_position + 10)

def display_button1():
    # Get the user's name and birth year
    birthyear = age.get().strip()  # Strip leading/trailing spaces
    username = name.get().strip()
    # Validate user input
    if not username.isalpha() or not birthyear.isdigit():  # Ensure username and birthyear are valid
        show = Label(homescreen, text='Please enter valid name and birth year', bg='red', pady=20, padx=20,
                     font='times')
        show.place(x=530, y=200)
        return
    try:
        # Create UserData instance
        user = UserData(username.capitalize(), int(birthyear))
    except ValueError:
        show = Label(homescreen, text='Please enter a valid birth year', bg='red', pady=20, padx=20, font='times')
        show.place(x=530, y=200)
        return

    # Display message if age is under 15
    if user.age < 15:
        show = Label(homescreen, text='Your age is not valid', bg='red', pady=20, padx=20, font='times')
        show.place(x=530, y=200)
    else:
        # Add the user to the list of users
        users_list.append(user)
        # Hide the homescreen and show the city select screen
        homescreen.withdraw()
        city_select = Tk()
        city_select.geometry('1600x900')
        city_select.title('City Select')
        city_select['bg'] = '#D8A1A6'
        dis_name = Label(city_select, text='Hello ' + username + ', please select the city:', font='times', bg='#D8A1A6')
        dis_name.place(x=0, y=0)
        # City select buttons
        dammambutton = Button(city_select, command=lambda: display_dammam(), height=3, width=20, text='Al Dammam', font='times')
        dammambutton.place(x=250, y=150)
        hasabutton = Button(city_select, command=lambda: display_hasa(), height=3, width=20, text='Al Hasa', font='times')
        hasabutton.place(x=550, y=150)
        jubailbutton = Button(city_select, command=lambda: display_jubail(), height=3, width=20, text='Jubail', font='times')
        jubailbutton.place(x=850, y=150)
        khoberbutton = Button(city_select, command=lambda: display_khober(), height=3, width=20, text='Khobar', font='times')
        khoberbutton.place(x=850, y=300)
        dhahranbutton = Button(city_select, command=lambda: display_dhahran(), height=3, width=20, text='Dhahran', font='times')
        dhahranbutton.place(x=550, y=300)
        # Show users list button
        user_button = Button(city_select, command=lambda: user_list(users_list), height=3, width=20, text='Show All Users', font='times')
        user_button.place(x=250, y=300)
        # Logout button to close the city selection window
        endbutton = Button(city_select, command=lambda: [city_select.destroy(), homescreen.quit()], height=3, width=20, text='Logout', font='times', fg='red')
        endbutton.place(x=550, y=550)
        city_select.mainloop()

# Home screen GUI
homescreen = Tk()
homescreen.geometry('1600x900')
homescreen.title('Home Page')
# Set background image
#background = PhotoImage(file='C:\\Users\\Fatimah\\OneDrive\\سطح المكتب\\paython picture\\homescreen.png')
#Label(image=background).pack()

# Direct user to enter their name and birth year
dirc = Label(text='Please enter your name here:', bg='#7D8AAB', font='times')
dirc.place(x=490, y=410)
dirc2 = Label(text='Please enter your birth year here:', bg='#7D8AAB', font='times')
dirc2.place(x=480, y=475)
# Create Entry widgets for name and age
name = Entry(width=30, bg='white')
name.place(x=520, y=450)
age = Entry(width=30, bg='white')
age.place(x=520, y=510)
# Buttons for deleting the input fields
del1 = Button(homescreen, command=lambda: name.delete(0, END), fg='black', pady=5, padx=30, text='Delete')
del1.place(x=750, y=440)
del2 = Button(homescreen, command=lambda: age.delete(0, END), fg='black', pady=5, padx=30, text='Delete')
del2.place(x=750, y=500)
# Login button to open the selection page
button1 = Button(homescreen, command=display_button1, text='Login', font='24', foreground='black', pady=10, padx=80)
button1.place(x=520, y=570)

labe3 = Label(text='This app was made by SF13 students\nFajer     2250001935\nFatimah    2250000126\nYara     2250003909\nJoud     2250003695\nFarah     2250001426')
labe3.place(x=950, y=20)

# Users list to store all user objects
users_list = []
def display_dammam():
    # Root window setup
    root = Tk()
    root.title("Welcome to ALSHARQIYA")
    root.geometry("1200x600")
    root.configure(bg="#27D8D8")

    # Function to go back to a specific page
    def go_back_to_page(page_frame, current_frame):
        current_frame.pack_forget()
        page_frame.pack()

    # Function to go back to the home page
    def go_back_to_home(current_frame):
        current_frame.pack_forget()
        home_frame.pack()

    # Function to show different pages
    def show_Restaurants_page():
        home_frame.pack_forget()
        Restaurants_page_frame.pack()

    def show_Parks_page():
        home_frame.pack_forget()
        Parks_page_frame.pack()

    def show_Malls_page():
        home_frame.pack_forget()
        Malls_page_frame.pack()

    def show_Cafes_page():
        home_frame.pack_forget()
        Cafe_page_frame.pack()

    def go_back_to_homePage():
        for frame in [Restaurants_page_frame, Parks_page_frame, Malls_page_frame, Cafe_page_frame]:
            frame.pack_forget()
        home_frame.pack()

    def show_specific_page(main_frame, specific_frame):
        main_frame.pack_forget()
        specific_frame.pack()

    # Home page frame
    home_frame = Frame(root)
    home_frame.pack()

    label = Label(home_frame, text="ALDammam", font="times")
    label.pack()

    # Buttons to navigate to pages
    button_submit = Button(home_frame, text="Restaurants", command=show_Restaurants_page)
    button_submit.pack()

    button_submit = Button(home_frame, text="Parks", command=show_Parks_page)
    button_submit.pack()

    button_submit = Button(home_frame, text="Malls", command=show_Malls_page)
    button_submit.pack()

    button_submit = Button(home_frame, text="Cafes", command=show_Cafes_page)
    button_submit.pack()

    # Restaurants page
    Restaurants_page_frame = Frame(root)

    restaurant1 = Button(Restaurants_page_frame, text="Fattah and Pine Restaurant",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant1_page))
    restaurant2 = Button(Restaurants_page_frame, text="Ottoman Taste Restaurant",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant2_page))
    restaurant3 = Button(Restaurants_page_frame, text="Plamida Restaurant",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant3_page))

    restaurant1.pack()
    restaurant2.pack()
    restaurant3.pack()

    restaurant1_page = Frame(root)
    restaurant2_page = Frame(root)
    restaurant3_page = Frame(root)

    ############# menu##############
    # Define the dictionary for the menu items and their prices
    my_dict = {"Rice with Lamb": 25, "Orange Juice": 12, "Tabbouleh": 16}

    # Define a function to display the dictionary in a Label widget
    def display_dict():
        dict_text = "\n".join([f"{key}: {value}" for key, value in my_dict.items()])
        menu_label.config(text=dict_text)

    # Create a label to display the dictionary
    menu_label = Label(restaurant1_page, text="Go to the menu page", font=("Arial", 14), padx=10, pady=10,
                       bg="lightgray")

    # Create a button to show the menu items
    menu_button = Button(restaurant1_page, text="Show the Menu", font=("Arial", 14), command=display_dict)

    # Restaurant 1 page (Fattah and Pine Restaurant)
    Label(restaurant1_page, text="Fattah and Pine Restaurant").pack()
    Label(restaurant1_page, text="A Lebanese cuisine restaurant located in eastern Dammam").pack()
    Label(restaurant1_page, text="Rating: 4.1").pack()
    Label(restaurant1_page, text="Location: https://g.co/kgs/V8YUWke").pack()

    # Add menu for restaurant 1 (Only here)
    menu_label.pack(padx=20, pady=10)  # Only display for this restaurant
    menu_button.pack(pady=10)

    Button(restaurant1_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant1_page, Restaurants_page_frame)).pack()

    # Restaurant 2 page (Ottoman Taste Restaurant)
    Label(restaurant2_page, text="Ottoman Taste Restaurant").pack()
    Label(restaurant2_page, text="A Turkish cuisine restaurant located on the Dammam Corniche").pack()
    Label(restaurant2_page, text="Rating: 4.5").pack()
    Label(restaurant2_page, text="Location: https://g.co/kgs/2sFusnx").pack()

    Button(restaurant2_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant2_page, Restaurants_page_frame)).pack()

    # Restaurant 3 page (Plamida Restaurant)
    Label(restaurant3_page, text="Plamida Restaurant").pack()
    Label(restaurant3_page, text="An international cuisine restaurant with a view of the sea").pack()
    Label(restaurant3_page, text="Rating: 4.1").pack()
    Label(restaurant3_page, text="Location: https://g.co/kgs/exNPsUX").pack()

    Button(restaurant3_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant3_page, Restaurants_page_frame)).pack()

    # Parks page
    Parks_page_frame = Frame(root)

    park1 = Button(Parks_page_frame, text="Park 1", command=lambda: show_specific_page(Parks_page_frame, park1_page))
    park2 = Button(Parks_page_frame, text="Park 2", command=lambda: show_specific_page(Parks_page_frame, park2_page))
    park3 = Button(Parks_page_frame, text="Park 3", command=lambda: show_specific_page(Parks_page_frame, park3_page))

    park1.pack()
    park2.pack()
    park3.pack()

    park1_page = Frame(root)
    park2_page = Frame(root)
    park3_page = Frame(root)

    Label(park1_page, text="Park 1").pack()
    Label(park1_page, text="Description: Green space with basketball court and walking track").pack()
    Label(park1_page, text="Rating: 4.3").pack()
    Label(park1_page, text="Location: https://g.co/kgs/cYnmWs8").pack()
    Button(park1_page, text="Go back to Parks main page",
           command=lambda: show_specific_page(park1_page, Parks_page_frame)).pack()

    Label(park2_page, text="Park 2").pack()
    Label(park2_page, text="Description: Abdullah Fouad Park with large green area and football fields").pack()
    Label(park2_page, text="Rating: 4.2").pack()
    Label(park2_page, text="Location: https://g.co/kgs/KtQDGfs").pack()
    Button(park2_page, text="Go back to Parks main page",
           command=lambda: show_specific_page(park2_page, Parks_page_frame)).pack()

    Label(park3_page, text="Park 3").pack()
    Label(park3_page, text="Description: A park surrounded by trees with paved walking paths").pack()
    Label(park3_page, text="Rating: 4.0").pack()
    Label(park3_page, text="Location: https://g.co/kgs/nrGA3h4").pack()
    Button(park3_page, text="Go back to Parks main page",
           command=lambda: show_specific_page(park3_page, Parks_page_frame)).pack()

    # Malls page
    Malls_page_frame = Frame(root)

    mall1 = Button(Malls_page_frame, text="ALNAKHEEL MALL",
                   command=lambda: show_specific_page(Malls_page_frame, mall1_page))
    mall2 = Button(Malls_page_frame, text="ALSHATE MALL",
                   command=lambda: show_specific_page(Malls_page_frame, mall2_page))
    mall3 = Button(Malls_page_frame, text="MARINA MALL",
                   command=lambda: show_specific_page(Malls_page_frame, mall3_page))

    mall1.pack()
    mall2.pack()
    mall3.pack()

    mall1_page = Frame(root)
    mall2_page = Frame(root)
    mall3_page = Frame(root)

    Label(mall1_page, text="ALNAKHEEL MALL").pack()
    Label(mall1_page, text="Description: A stylish contemporary shopping mall with international retail chains").pack()
    Label(mall1_page, text="Rating: 4.5").pack()
    Label(mall1_page, text="Location: https://g.co/kgs/1BZDXtT").pack()
    Button(mall1_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall1_page, Malls_page_frame)).pack()

    Label(mall2_page, text="ALSHATI MALL").pack()
    Label(mall2_page, text="Description: A shopping center with supermarkets and local stores").pack()
    Label(mall2_page, text="Rating: 3.9").pack()
    Label(mall2_page, text="Location: https://g.co/kgs/cChqSmw").pack()
    Button(mall2_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall2_page, Malls_page_frame)).pack()

    Label(mall3_page, text="MARINA MALL").pack()
    Label(mall3_page, text="Description: A mall with restaurants and cafes").pack()
    Label(mall3_page, text="Rating: 4.0").pack()
    Label(mall3_page, text="Location: https://g.co/kgs/uCsEnQY").pack()
    Button(mall3_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall3_page, Malls_page_frame)).pack()

    # Cafes page
    Cafe_page_frame = Frame(root)

    cafe1 = Button(Cafe_page_frame, text="Leto Cafe", command=lambda: show_specific_page(Cafe_page_frame, cafe1_page))
    cafe2 = Button(Cafe_page_frame, text="Dazzling Cafe",
                   command=lambda: show_specific_page(Cafe_page_frame, cafe2_page))
    cafe3 = Button(Cafe_page_frame, text="Benola Cafe", command=lambda: show_specific_page(Cafe_page_frame, cafe3_page))

    cafe1.pack()
    cafe2.pack()
    cafe3.pack()

    cafe1_page = Frame(root)
    cafe2_page = Frame(root)
    cafe3_page = Frame(root)

    Label(cafe1_page, text="Leto Cafe").pack()
    Label(cafe1_page, text="Description: A cafe featuring sweets and coffee, located in Al Nakheel Mall").pack()
    Label(cafe1_page, text="Rating: 4.6").pack()
    Label(cafe1_page, text="Location: https://maps.app.goo.gl/v9zqCsJ9vaPzaHvK6").pack()
    Button(cafe1_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe1_page, Cafe_page_frame)).pack()

    Label(cafe2_page, text="Dazzling Cafe").pack()
    Label(cafe2_page, text="Description: A cafe with Arabic and Western sweets, coffee, and juices").pack()
    Label(cafe2_page, text="Rating: 4.6").pack()
    Label(cafe2_page, text="Location: https://g.co/kgs/QrFTeFY").pack()
    Button(cafe2_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe2_page, Cafe_page_frame)).pack()

    Label(cafe3_page, text="Beanola Cafe").pack()
    Label(cafe3_page, text="Description: A cafe with coffee and sweets, offering a view of the sea").pack()
    Label(cafe3_page, text="Rating: 3.8").pack()
    Label(cafe3_page, text="Location: https://g.co/kgs/QH16ZQ1").pack()
    Button(cafe3_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe3_page, Cafe_page_frame)).pack()
    Button(Cafe_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    Button(Malls_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    Button(Parks_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()

    root.mainloop()
def display_hasa():
    # Create main window
    root = Tk()
    root.title("ALSHARQIYA")
    root.geometry("1200x600")

    # Function to display specific pages
    def show_specific_page(current_frame, specific_frame):
        current_frame.pack_forget()
        specific_frame.pack()

    # Function to go back to a specific page
    def go_back_to_page(page_frame, current_frame):
        current_frame.pack_forget()
        page_frame.pack()

    # Function to go back to the home page
    def go_back_to_home(current_frame):
        current_frame.pack_forget()
        home_frame.pack()

    # Home/Main page
    home_frame = Frame(root)
    home_frame.pack()

    label = Label(home_frame, text="AL AHSA", bg="dark green", fg="white", font=('Impact', 40, 'bold'))
    label.pack(side=TOP)

    # Main page buttons
    button_submit = Button(home_frame, text="Restaurants", bg="red", fg="black",
                           command=lambda: show_specific_page(home_frame, Restaurants_page_frame))
    button_submit.pack(side=LEFT)
    button_submit = Button(home_frame, text="Parks", bg="green", fg="black",
                           command=lambda: show_specific_page(home_frame, Parks_page_frame))
    button_submit.pack(side=LEFT)
    button_submit = Button(home_frame, text="Malls", bg="blue", fg="white",
                           command=lambda: show_specific_page(home_frame, Malls_page_frame))
    button_submit.pack(side=LEFT)
    button_submit = Button(home_frame, text="Cafes", bg="brown", fg="white",
                           command=lambda: show_specific_page(home_frame, Cafe_page_frame))
    button_submit.pack(side=LEFT)

    # Restaurants Page
    Restaurants_page_frame = Frame(root)
    restaurant1 = Button(Restaurants_page_frame, text="DAR BASMA",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant1_page))
    restaurant2 = Button(Restaurants_page_frame, text="Lava",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant2_page))
    restaurant3 = Button(Restaurants_page_frame, text="Symbol",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant3_page))

    restaurant1.pack(side=LEFT)
    restaurant2.pack(side=LEFT)
    restaurant3.pack(side=LEFT)

    # Back to Home button for Restaurants page
    back_to_home_restaurants = Button(Restaurants_page_frame, text="Back", fg="black",
                                      command=lambda: go_back_to_home(Restaurants_page_frame))
    back_to_home_restaurants.pack(side=LEFT)

    # Restaurant pages
    restaurant1_page = Frame(root)
    restaurant2_page = Frame(root)
    restaurant3_page = Frame(root)

    Label(restaurant1_page, text="DAR BASMA", fg="red", font=("Times", 20)).pack()
    Label(restaurant1_page,
          text="Here is the description for the place: \nDar Basma Restaurant is a restaurant that serves dishes from the Al-Ahsa region.").pack()
    Label(restaurant1_page, text="Rating: 4.1").pack()
    Label(restaurant1_page, text="Location: https://maps.app.goo.gl/tpAe4ZCh44H9BMhv6").pack()
    Button(restaurant1_page, text="Back",
           command=lambda: go_back_to_page(Restaurants_page_frame, restaurant1_page)).pack()

    Label(restaurant2_page, text="Lava", fg="red", font=("Times", 20)).pack()
    Label(restaurant2_page,
          text="Here is the description for the place: \nA restaurant that offers a unique and different dining experience of Arabic and international dishes.").pack()
    Label(restaurant2_page, text="Rating: 4.1").pack()
    Label(restaurant2_page, text="Location: https://maps.app.goo.gl/UHt7RzukvLuJP7Zb6").pack()
    Button(restaurant2_page, text="Back",
           command=lambda: go_back_to_page(Restaurants_page_frame, restaurant2_page)).pack()

    Label(restaurant3_page, text="Symbol", fg="red", font=("Times", 20)).pack()
    Label(restaurant3_page,
          text="Here is the description for the place: Your destination to experience a unique and diverse range of fast food.").pack()
    Label(restaurant3_page, text="Rating: 4.4").pack()
    Label(restaurant3_page, text="Location: https://maps.app.goo.gl/oSg29AEu648VLXbe7").pack()
    Button(restaurant3_page, text="Back",
           command=lambda: go_back_to_page(Restaurants_page_frame, restaurant3_page)).pack()

    # Parks Page
    Parks_page_frame = Frame(root)
    park1 = Button(Parks_page_frame, text="Al Qarah Mountain",
                   command=lambda: show_specific_page(Parks_page_frame, park1_page))
    park2 = Button(Parks_page_frame, text="Qaisariah Souq",
                   command=lambda: show_specific_page(Parks_page_frame, park2_page))
    park3 = Button(Parks_page_frame, text="Mushqqar Park",
                   command=lambda: show_specific_page(Parks_page_frame, park3_page))

    park1.pack(side=LEFT)
    park2.pack(side=LEFT)
    park3.pack(side=LEFT)

    # Back to Home button for Parks page
    back_to_home_parks = Button(Parks_page_frame, text="Back", fg="black",
                                command=lambda: go_back_to_home(Parks_page_frame))
    back_to_home_parks.pack(side=LEFT)

    # Park pages
    park1_page = Frame(root)
    park2_page = Frame(root)
    park3_page = Frame(root)

    Label(park1_page, text="Al Qarah Mountain", fg="green", font=("Times", 20)).pack()
    Label(park1_page,
          text="Here is the description for the place: Mount Qarah is one of the most prominent tourist attractions in Al-Ahsa Governorate...").pack()
    Label(park1_page, text="Rating: 4.1").pack()
    Label(park1_page, text="Location: https://maps.app.goo.gl/dDTENZYQ24nZ6CPx9").pack()
    Button(park1_page, text="Back to Parks page", command=lambda: go_back_to_page(Parks_page_frame, park1_page)).pack()

    Label(park2_page, text="Qaisariah Souq", fg="green", font=("Times", 20)).pack()
    Label(park2_page,
          text="Here is the description for the place: Al Qaisariya Market is one of the oldest and most famous traditional markets in the Kingdom...").pack()
    Label(park2_page, text="Rating: 4.4").pack()
    Label(park2_page, text="Location: https://maps.app.goo.gl/qN5HfuMzVFsuMSrU8").pack()
    Button(park2_page, text="Back", command=lambda: go_back_to_page(Parks_page_frame, park2_page)).pack()

    Label(park3_page, text="Mushqqar Park", fg="green", font=("Times", 20)).pack()
    Label(park3_page,
          text="Here is the description for the place: Al-Mashqar Park in Al-Ahsa is a wonderful natural destination that offers a peaceful experience...").pack()
    Label(park3_page, text="Rating: 4.2").pack()
    Label(park3_page, text="Location: https://maps.app.goo.gl/XsaNFccCVFGgEErb7").pack()
    Button(park3_page, text="Back", command=lambda: go_back_to_page(Parks_page_frame, park3_page)).pack()

    # Malls Page
    Malls_page_frame = Frame(root)
    mall1 = Button(Malls_page_frame, text="ALahsa Mall",
                   command=lambda: show_specific_page(Malls_page_frame, mall1_page))
    mall2 = Button(Malls_page_frame, text="Othaim Mall",
                   command=lambda: show_specific_page(Malls_page_frame, mall2_page))

    mall1.pack(side=LEFT)
    mall2.pack(side=LEFT)

    # Back to Home button for Malls page
    back_to_home_malls = Button(Malls_page_frame, text="Back", fg="black",
                                command=lambda: go_back_to_home(Malls_page_frame))
    back_to_home_malls.pack(side=LEFT)

    # Mall pages
    mall1_page = Frame(root)
    mall2_page = Frame(root)

    Label(mall1_page, text="ALahsa Mall", fg="blue", font=("Times", 20)).pack()
    Label(mall1_page, text="Here is the description for the place: The mall has many shops and restaurants...").pack()
    Label(mall1_page, text="Rating: 4.2").pack()
    Label(mall1_page, text="Location: https://maps.app.goo.gl/ByUsnHtLBvsGyUhQA").pack()
    Button(mall1_page, text="Back", command=lambda: go_back_to_page(Malls_page_frame, mall1_page)).pack()

    Label(mall2_page, text="Othaim Mall", fg="blue", font=("Times", 20)).pack()
    Label(mall2_page,
          text="Here is the description for the place: The mall includes many distinguished restaurants...").pack()
    Label(mall2_page, text="Rating: 4.2").pack()
    Label(mall2_page, text="Location: https://maps.app.goo.gl/ogwV8TPvp1prmEjT6").pack()
    Button(mall2_page, text="Back", command=lambda: go_back_to_page(Malls_page_frame, mall2_page)).pack()

    # Cafes Page
    Cafe_page_frame = Frame(root)
    cafe1 = Button(Cafe_page_frame, text="Dopeamine", command=lambda: show_specific_page(Cafe_page_frame, cafe1_page))
    cafe2 = Button(Cafe_page_frame, text="Quite", command=lambda: show_specific_page(Cafe_page_frame, cafe2_page))
    cafe3 = Button(Cafe_page_frame, text="Panama", command=lambda: show_specific_page(Cafe_page_frame, cafe3_page))

    cafe1.pack(side=LEFT)
    cafe2.pack(side=LEFT)
    cafe3.pack(side=LEFT)

    # Back to Home button for Cafes page
    back_to_home_cafes = Button(Cafe_page_frame, text="Back", fg="black",
                                command=lambda: go_back_to_home(Cafe_page_frame))
    back_to_home_cafes.pack(side=LEFT)

    # Cafe pages
    cafe1_page = Frame(root)
    cafe2_page = Frame(root)
    cafe3_page = Frame(root)

    Label(cafe1_page, text="Dopeamine", fg="brown", font=("Times", 20)).pack()
    Label(cafe1_page,
          text="Here is the description for the place: Dopamine Café in Al-Ahsa is an ideal destination...").pack()
    Label(cafe1_page, text="Rating: 4.4").pack()
    Label(cafe1_page, text="Location: https://maps.app.goo.gl/Ay4EiNcTKxbibjgr9").pack()
    Button(cafe1_page, text="Back", command=lambda: go_back_to_page(Cafe_page_frame, cafe1_page)).pack()

    Label(cafe2_page, text="Quite", fg="brown", font=("Times", 20)).pack()
    Label(cafe2_page, text="Here is the description for the place: Quiet Café is a peaceful place...").pack()
    Label(cafe2_page, text="Rating: 3.5").pack()
    Label(cafe2_page, text="Location: https://maps.app.goo.gl/cKLQkSePGyd6q5cd6").pack()
    Button(cafe2_page, text="Back", command=lambda: go_back_to_page(Cafe_page_frame, cafe2_page)).pack()

    Label(cafe3_page, text="Panama", fg="brown", font=("Times", 20)).pack()
    Label(cafe3_page, text="Here is the description for the place: Panama Cafe is a unique destination...").pack()
    Label(cafe3_page, text="Rating: 4.0").pack()
    Label(cafe3_page, text="Location: https://maps.app.goo.gl/vKyUAaDho8igeS8JA").pack()
    Button(cafe3_page, text="Back", command=lambda: go_back_to_page(Cafe_page_frame, cafe3_page)).pack()

    root.mainloop()
def display_jubail():
    import webbrowser

    window = Tk()
    window.geometry('1600x900')
    window.title("Welcome to Al Jubail!")
    window.configure(bg="skyblue")

    # List of malls with Google search links

    malls = {
        "Al Jubail Mall": "https://www.google.com/search?q=Al+Jubail+Mall+Jubail",
        "Piano Mall": "https://www.google.com/search?q=Piano+Mall+Jubail",
        "Othaim Mall": "https://www.google.com/search?q=Othaim+Mall+Jubail",
        "Jubail Plaza": "https://www.google.com/search?q=Jubail+Plaza+Jubail",
    }

    # List of restaurants with Google search links
    restaurants = {
        "The Blue Restaurant": "https://www.google.com/search?q=The+Blue+Restaurant+Jubail",
        "Al Baik Restaurant": "https://www.google.com/search?q=Al+Baik+Restaurant+Jubail",
        "Pizza Hut": "https://www.google.com/search?q=Pizza+Hut+Jubail",
        "Kanzo Restaurant": "https://www.google.com/search?q=Kanzo+Restaurant+Jubail",
    }

    # List of parks with search links on Google Maps
    parks = {
        "Al Qanah Park": "https://www.google.com/maps?q=Al+Qanah+Park+Jubail",
        "Peace Park": "https://www.google.com/maps?q=Peace+Park+Jubail",
        "Al Salam Park": "https://www.google.com/maps?q=Al+Salam+Park+Jubail",
        "Taybah Park": "https://www.google.com/maps?q=Taybah+Park+Jubail",
    }

    # List of cafes with Google search links

    cafes = {
        "Starbucks": "https://www.google.com/search?q=Starbucks+Jubail",
        "Kyan Cafe": "https://www.google.com/search?q=Kyan+Cafe+Jubail",
        "Dunkin'": "https://www.google.com/search?q=Dunkin+Jubail",
        "Coffee Story": "https://www.google.com/search?q=Coffee+Story+Jubail",
    }

    # Function to open a link in the browser

    def open_google_search(selected, category):
        url = None
        if category == "restaurant":
            url = restaurants.get(selected)
        elif category == "mall":
            url = malls.get(selected)
        elif category == "park":
            url = parks.get(selected)
        elif category == "cafe":
            url = cafes.get(selected)

        if url:
            webbrowser.open(url)

    # Storage variables

    selected_mall =StringVar()
    selected_mall.set("Choose a mall")

    selected_restaurant = StringVar()
    selected_restaurant.set("Choose a restaurant")

    selected_park = StringVar()
    selected_park.set("Choose a park")

    selected_cafe = StringVar()
    selected_cafe.set("Choose a café")

    # Function to show a list of moles

    def show_malls():
        dropdown = OptionMenu(
            window,
            selected_mall,
            *malls.keys(),
            command=lambda selected: open_google_search(selected, "mall")
        )
        dropdown.config(width=20, font=("Arial", 12))
        dropdown.place(relx=1.0, rely=0.1, anchor="ne", x=-10, y=40)

    # Function to show the list of restaurants

    def show_restaurants():
        dropdown = OptionMenu(
            window,
            selected_restaurant,
            *restaurants.keys(),
            command=lambda selected: open_google_search(selected, "restaurant")
        )
        dropdown.config(width=20, font=("Arial", 12))
        dropdown.place(relx=0.0, rely=0.1, anchor="nw", x=10, y=40)

    # Function to show the list of parks

    def show_parks():
        dropdown =OptionMenu(
            window,
            selected_park,
            *parks.keys(),
            command=lambda selected: open_google_search(selected, "park")
        )
        dropdown.config(width=20, font=("Arial", 12))
        dropdown.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-65)

    # Function to show the list of cafes

    def show_cafes():
        dropdown =OptionMenu(
            window,
            selected_cafe,
            *cafes.keys(),
            command=lambda selected: open_google_search(selected, "cafe")
        )
        dropdown.config(width=20, font=("Arial", 12))
        dropdown.place(relx=0.0, rely=1.0, anchor="sw", x=10, y=-65)
    # Create a restaurants button
    restaurant_button =Button(window,text="Restaurants",font=("Arial", 30),bg="skyblue",fg="black",command=show_restaurants)
    restaurant_button.grid(row=0, column=0, padx=10, pady=10, sticky="nw")
    # Create moles button
    mall_button = Button(window,text="Malls",font=("Arial", 30),bg="skyblue",fg="black",command=show_malls)
    mall_button.place(relx=1.0, rely=0.0, anchor="ne", x=-10, y=10)
    # Create button parks
    park_button = Button(window,text="Gardens",font=("Arial", 30),bg="skyblue",fg="black",command=show_parks)
    park_button.place(relx=1.0, rely=1.0, anchor="se", x=-10, y=-130)
    # Create a café button
    cafe_button = Button(window,text="Cafes",font=("Arial", 30),bg="skyblue",fg="black",command=show_cafes)
    cafe_button.place(relx=0.0, rely=1.0, anchor="sw", x=10, y=-130)
    # Text in the middle of the page
    center_label =Label(window,text="Al Jubail",font=("Arial", 90, "bold"),bg="skyblue",fg="pink")
    center_label.place(relx=0.5, rely=0.5, anchor="center")

    window.mainloop()
def display_khober():

    # Creating main window
    root = Tk()
    root.title("Khobar")
    root.geometry("1600x900")
    # Set the background color of the whole window
    root['bg'] = "#9fa8dc"

    # Function to show the Restaurants page
    def show_Restaurants_page():
        home_frame.pack_forget()
        Restaurants_page_frame.pack(expand=True, fill="both")

    # Function to show the Parks page
    def show_Parks_page():
        home_frame.pack_forget()
        Parks_page_frame.pack(expand=True, fill="both")

    # Function to show the Malls page
    def show_Malls_page():
        home_frame.pack_forget()
        Malls_page_frame.pack(expand=True, fill="both")

    # Function to show the Cafes page
    def show_Cafes_page():
        home_frame.pack_forget()
        Cafe_page_frame.pack(expand=True, fill="both")

    # Function to go back to the home page
    def go_back_to_homePage():
        home_frame.pack(expand=True, fill="both")
        for frame in (Restaurants_page_frame, Parks_page_frame, Malls_page_frame, Cafe_page_frame,
                      restaurant1_page, restaurant2_page, restaurant3_page,
                      park1_page, park2_page, park3_page,
                      mall1_page, mall2_page, mall3_page,
                      cafe1_page, cafe2_page, cafe3_page):
            frame.pack_forget()

    def go_back_to_restaurantsPage():
        Restaurants_page_frame.pack(expand=True, fill="both")
        for frame in (restaurant1_page, restaurant2_page, restaurant3_page):
            frame.pack_forget()

    def go_back_to_parksPage():
        Parks_page_frame.pack(expand=True, fill="both")
        for frame in (park1_page, park2_page, park3_page):
            frame.pack_forget()

    def go_back_to_mallsPage():
        Malls_page_frame.pack(expand=True, fill="both")
        for frame in (mall1_page, mall2_page, mall3_page):
            frame.pack_forget()

    def go_back_to_cafesPage():
        Cafe_page_frame.pack(expand=True, fill="both")
        for frame in (cafe1_page, cafe2_page, cafe3_page):
            frame.pack_forget()

    def show_specific_page(main_frame, specific_frame):
        main_frame.pack_forget()
        specific_frame.pack(expand=True, fill="both")

        # Function to go back to a specific page
        def go_back_to_page(page_frame, current_frame):
            current_frame.pack_forget()
            page_frame.pack()

        # Function to go back to the home page
        def go_back_to_home(current_frame):
            current_frame.pack_forget()
            home_frame.pack()

    # Home page
    home_frame = Frame(root, bg="#9fa8dc")
    home_frame.pack(expand=True, fill="both")

    label = Label(home_frame, text="Khobar", bg="#9fa8dc", font=("Arial", 24))
    label.grid(row=0, column=0, columnspan=2, pady=10)

    # Main page buttons - 2 rows of buttons (centered)
    button_restaurants = Button(home_frame, text="Restaurants", command=show_Restaurants_page, height=4, width=20)
    button_restaurants.grid(row=1, column=0, pady=10)

    button_parks = Button(home_frame, text="Parks", command=show_Parks_page, height=4, width=20)
    button_parks.grid(row=1, column=1, pady=10)

    button_malls = Button(home_frame, text="Malls", command=show_Malls_page, height=4, width=20)
    button_malls.grid(row=2, column=0, pady=10)

    button_cafes = Button(home_frame, text="Cafes", command=show_Cafes_page, height=4, width=20)
    button_cafes.grid(row=2, column=1, pady=10)

    # Adding the comment entry section under the last button
    comment_label = Label(home_frame, text="Feel free to comment on Khobar", bg="#9fa8dc", font=("Arial", 24))
    comment_label.grid(row=3, column=0, columnspan=2, pady=10)

    comment_entry = Text(home_frame, width=30, height=5)  # Text entry field
    comment_entry.grid(row=4, column=0, columnspan=2, pady=10)

    # Make the columns expand to center the widgets properly
    home_frame.grid_columnconfigure(0, weight=1)
    home_frame.grid_columnconfigure(1, weight=1)

    ############## Restaurants ############
    Restaurants_page_frame = Frame(root, bg="#9fa8dc")
    restaurant1 = Button(Restaurants_page_frame, text="Blue Garden Restaurant", font='times', height=4, width=30,
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant1_page))
    restaurant2 = Button(Restaurants_page_frame, text="The Pantry Restaurant", font='times', height=4, width=30,
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant2_page))
    restaurant3 = Button(Restaurants_page_frame, text="Paradise Restaurant", font='times', height=4, width=30,
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant3_page))
    restaurant1.pack(pady=10)
    restaurant2.pack(pady=10)
    restaurant3.pack(pady=10)

    restaurant1_page = Frame(root, bg="#9fa8dc")
    restaurant2_page = Frame(root, bg="#9fa8dc")
    restaurant3_page = Frame(root, bg="#9fa8dc")

    # Restaurant Pages Content
    Label(restaurant1_page, font='times', height=4, width=30, text="Blue Garden Restaurant", bg="#9fa8dc").pack(pady=10)
    Label(restaurant1_page, font='times', height=4, width=30, text="There are outdoor seating areas, a fireplace.",
          bg="#9fa8dc").pack(pady=10)
    Label(restaurant1_page, font='times', height=4, width=30, text="Rated 5 stars and 4 stars in reviews.",
          bg="#9fa8dc").pack(pady=10)
    Button(restaurant1_page, font='times', height=4, width=30, text="Back to Restaurants Page",
           command=go_back_to_restaurantsPage).pack(pady=10)

    Label(restaurant2_page, font='times', height=4, width=30, text="The Pantry Restaurant", bg="#9fa8dc").pack(pady=10)
    Label(restaurant2_page, font='times', text="Features a buffet and discounted food with a fireplace.",
          bg="#9fa8dc").pack(pady=10)
    Label(restaurant2_page, font='times', height=4, width=30, text="Rated 4.4 stars.", bg="#9fa8dc").pack(pady=10)
    Button(restaurant2_page, font='times', height=4, width=30, text="Back to Restaurants Page",
           command=go_back_to_restaurantsPage).pack(pady=10)

    Label(restaurant3_page, font='times', height=4, width=30, text="Paradise Restaurant", bg="#9fa8dc").pack(pady=10)
    Label(restaurant3_page, font='times', height=4, width=30, text="There is a drive-thru. Indian dishes.",
          bg="#9fa8dc").pack(pady=10)
    Label(restaurant3_page, font='times', height=4, width=30, text="Rated 4 stars.", bg="#9fa8dc").pack(pady=10)
    Button(restaurant3_page, font='times', height=4, width=30, text="Back to Restaurants Page",
           command=go_back_to_restaurantsPage).pack(pady=10)

    ############ Parks ##########
    Parks_page_frame = Frame(root, bg="#9fa8dc")
    park1 = Button(Parks_page_frame, text="Prince Faisal Bin Fahd Marine Park", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Parks_page_frame, park1_page))
    park2 = Button(Parks_page_frame, text="The Rose Garden", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Parks_page_frame, park2_page))
    park3 = Button(Parks_page_frame, text="Al Qusaibi Park", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Parks_page_frame, park3_page))
    park1.pack(pady=10)
    park2.pack(pady=10)
    park3.pack(pady=10)

    park1_page = Frame(root, bg="#9fa8dc")
    park2_page = Frame(root, bg="#9fa8dc")
    park3_page = Frame(root, bg="#9fa8dc")

    # Park Pages Content
    Label(park1_page, font='times', height=4, width=30, text="Prince Faisal Bin Fahd Marine Park", bg="#9fa8dc").pack(
        pady=10)
    Label(park1_page, font='times',
          text="Waterfront. This large park covers an area of more than 500,000 square meters.",
          bg="#9fa8dc").pack(pady=10)
    Label(park1_page, font='times', height=4, width=30, text="Rated 4.7 stars.", bg="#9fa8dc").pack(pady=10)
    Button(park1_page, font='times', height=4, width=30, text="Back to Parks Page",
           command=go_back_to_parksPage).pack(pady=10)

    Label(park2_page, font='times', height=4, width=30, text="The Rose Garden", bg="#9fa8dc").pack(pady=10)
    Label(park2_page, font='times', text="Al Khobar Rose Garden has a variety of beautiful plants, flowers, and trees.",
          bg="#9fa8dc").pack(pady=10)
    Label(park2_page, font='times', height=4, width=30, text="Rated 4.2 stars.", bg="#9fa8dc").pack(pady=10)
    Button(park2_page, font='times', height=4, width=30, text="Back to Parks Page",
           command=go_back_to_parksPage).pack(pady=10)

    Label(park3_page, font='times', height=4, width=30, text="Al Qusaibi Park", bg="#9fa8dc").pack(pady=10)
    Label(park3_page, font='times', text="Al Qusaibi Park is a beautiful park with open spaces and shaded areas.",
          bg="#9fa8dc").pack(pady=10)
    Label(park3_page, font='times', height=4, width=30, text="Rated 4 stars.", bg="#9fa8dc").pack(pady=10)
    Button(park3_page, font='times', height=4, width=30, text="Back to Parks Page",
           command=go_back_to_parksPage).pack(pady=10)

    ################ Malls ############
    Malls_page_frame = Frame(root, bg="#9fa8dc")
    mall1 = Button(Malls_page_frame, text="Mall of Khobar", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Malls_page_frame, mall1_page))
    mall2 = Button(Malls_page_frame, text="Al Rashid Mall", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Malls_page_frame, mall2_page))
    mall3 = Button(Malls_page_frame, text="Al Seef Mall", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Malls_page_frame, mall3_page))
    mall1.pack(pady=10)
    mall2.pack(pady=10)
    mall3.pack(pady=10)

    mall1_page = Frame(root, bg="#9fa8dc")
    mall2_page = Frame(root, bg="#9fa8dc")
    mall3_page = Frame(root, bg="#9fa8dc")

    # Mall Pages Content
    Label(mall1_page, font='times', height=4, width=30, text="Mall of Khobar", bg="#9fa8dc").pack(pady=10)
    Label(mall1_page, font='times', text="Mall of khobar is a large shopping center, with an atrium, high-end brands.",
          bg="#9fa8dc").pack(pady=10)
    Label(mall1_page, font='times', text="Rated 5 stars.", bg="#9fa8dc").pack(pady=10)
    Button(mall1_page, font='times', height=4, width=30, text="Back to Malls Page",
           command=go_back_to_mallsPage).pack(pady=10)

    Label(mall2_page, font='times', height=4, width=30, text="Al Rashid Mall", bg="#9fa8dc").pack(pady=10)
    Label(mall2_page, font='times', text="Large shopping mall with various brands, restaurants, and events.",
          bg="#9fa8dc").pack(pady=10)
    Label(mall2_page, font='times', text="Rated 4.8 stars.", bg="#9fa8dc").pack(pady=10)
    Button(mall2_page, font='times', height=4, width=30, text="Back to Malls Page",
           command=go_back_to_mallsPage).pack(pady=10)

    Label(mall3_page, font='times', height=4, width=30, text="Al Seef Mall", bg="#9fa8dc").pack(pady=10)
    Label(mall3_page, font='times', text="A large shopping mall featuring various brands and an entertainment section.",
          bg="#9fa8dc").pack(pady=10)
    Label(mall3_page, font='times', height=4, width=30, text="Rated 4.5 stars.", bg="#9fa8dc").pack(pady=10)
    Button(mall3_page, font='times', height=4, width=30, text="Back to Malls Page",
           command=go_back_to_mallsPage).pack(pady=10)

    ################ Cafes ##############
    Cafe_page_frame = Frame(root, bg="#9fa8dc")
    cafe1 = Button(Cafe_page_frame, text="Cafe Mocha", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Cafe_page_frame, cafe1_page))
    cafe2 = Button(Cafe_page_frame, text="Lavender Cafe", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Cafe_page_frame, cafe2_page))
    cafe3 = Button(Cafe_page_frame, text="Cafe de Paris", font='times', height=4, width=30,
                   command=lambda: show_specific_page(Cafe_page_frame, cafe3_page))
    cafe1.pack(pady=10)
    cafe2.pack(pady=10)
    cafe3.pack(pady=10)

    cafe1_page = Frame(root, bg="#9fa8dc")
    cafe2_page = Frame(root, bg="#9fa8dc")
    cafe3_page = Frame(root, bg="#9fa8dc")

    # Cafe Pages Content
    Label(cafe1_page, font='times', height=4, width=30, text="Cafe Mocha", bg="#9fa8dc").pack(pady=10)
    Label(cafe1_page, font='times', text="A cozy cafe known for its exceptional coffee and quiet ambiance.",
          bg="#9fa8dc").pack(pady=10)
    Label(cafe1_page, font='times', text="Rated 4.6 stars.", bg="#9fa8dc").pack(pady=10)
    Button(cafe1_page, font='times', height=4, width=30, text="Back to Cafes Page",
           command=go_back_to_cafesPage).pack(pady=10)

    Label(cafe2_page, font='times', height=4, width=30, text="Lavender Cafe", bg="#9fa8dc").pack(pady=10)
    Label(cafe2_page, font='times', text="A quaint cafe offering a variety of teas, pastries, and coffee drinks.",
          bg="#9fa8dc").pack(pady=10)
    Label(cafe2_page, font='times', text="Rated 4.3 stars.", bg="#9fa8dc").pack(pady=10)
    Button(cafe2_page, font='times', height=4, width=30, text="Back to Cafes Page",
           command=go_back_to_cafesPage).pack(pady=10)

    Label(cafe3_page, font='times', height=4, width=30, text="Cafe de Paris", bg="#9fa8dc").pack(pady=10)
    Label(cafe3_page, font='times', text="A charming cafe offering French-inspired pastries and beverages.",
          bg="#9fa8dc").pack(pady=10)
    Label(cafe3_page, font='times', text="Rated 4.7 stars.", bg="#9fa8dc").pack(pady=10)
    Button(cafe3_page, font='times', height=4, width=30, text="Back to Cafes Page",
           command=go_back_to_cafesPage).pack(pady=10)
    Button(Cafe_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    Button(Malls_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    Button(Parks_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    Button(Restaurants_page_frame, height=4, width=30, text="Back", command=go_back_to_homePage).pack()
    root.mainloop()
def display_dhahran():
    # creat main window
    root = Tk()
    root.title("Dharan")
    root.geometry("1600x900")

    # function to show restaurants page
    def show_Restaurants_page():
        home_frame.pack_forget()
        Restaurants_page_frame.pack()

    # function to show parks page
    def show_Parks_page():
        home_frame.pack_forget()
        Parks_page_frame.pack()

    # function to show malls page
    def show_Malls_page():
        home_frame.pack_forget()
        Malls_page_frame.pack()

    # function to show cafes page
    def show_Cafes_page():
        home_frame.pack_forget()
        Cafe_page_frame.pack()

    # function to go back to hame page
    def go_back_to_homePage():
        home_frame.pack()
        for frame in (Restaurants_page_frame, Parks_page_frame, Malls_page_frame, Cafe_page_frame,
                      restaurant1_page, restaurant2_page, restaurant3_page,
                      park1_page, park2_page, mall1_page, mall2_page, mall3_page,
                      cafe1_page, cafe2_page, cafe3_page):
            frame.pack_forget()

    def show_specific_page(main_frame, specific_frame):
        main_frame.pack_forget()
        specific_frame.pack()

    # home page
    home_frame = Frame(root)
    home_frame.pack()

    label = Label(home_frame, fg="dark blue", text="Dhahran", font=("Times", 60))
    label.pack(side=TOP, pady=100)

    #############     buttons for maim pages        ################

    button_submit = Button(home_frame, text="Restaurants", command=show_Restaurants_page)
    button_submit.pack(side=LEFT, padx=10, pady=10)

    button_submit = Button(home_frame, text="Parks", command=show_Parks_page)
    button_submit.pack(side=LEFT, padx=10, pady=10)

    button_submit = Button(home_frame, text="Malls", command=show_Malls_page)
    button_submit.pack(side=LEFT, padx=10, pady=10)

    button_submit = Button(home_frame, text="Cafes", command=show_Cafes_page)
    button_submit.pack(side=LEFT, padx=10, pady=10)

    ##############     restaurants     ############
    Restaurants_page_frame = Frame(root)
    restaurant1 = Button(Restaurants_page_frame, text="Pizza Bar IOI Restaraunt",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant1_page))
    restaurant2 = Button(Restaurants_page_frame, text="eat'sy Restaurant",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant2_page))
    restaurant3 = Button(Restaurants_page_frame, text="Leros Restaurant",
                         command=lambda: show_specific_page(Restaurants_page_frame, restaurant3_page))
    restaurant1.pack(side=LEFT, padx=10, pady=200)
    restaurant2.pack(side=LEFT, padx=10, pady=200)
    restaurant3.pack(side=LEFT, padx=10, pady=200)

    restaurant1_page = Frame(root)
    restaurant2_page = Frame(root)
    restaurant3_page = Frame(root)

    Label(restaurant1_page, text="Pizza Bar IOI Restaraunt", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(restaurant1_page, text="Pizza bar is the best choice If you are looking for \nA pure Italian foods.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(restaurant1_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/5TeGLHDxmA7tZAYz7").grid(
        row=2, column=0, padx=10, pady=10)
    Button(restaurant1_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant1_page, Restaurants_page_frame), bg="light green").grid(row=3,
                                                                                                                column=0,
                                                                                                                columnspan=2,
                                                                                                                padx=10,
                                                                                                                pady=10)

    Label(restaurant2_page, text="eat'sy Restaurant", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(restaurant2_page, text="eat'sy is A special restaurant that serves high \nquality.Italian dishes").grid(row=1,
                                                                                                                  column=0,
                                                                                                                  padx=10,
                                                                                                                  pady=10)
    Label(restaurant2_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/KptR18LAkRLPHnQHA").grid(
        row=2, column=0, padx=10, pady=10)
    Button(restaurant2_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant2_page, Restaurants_page_frame), bg="light green").grid(row=3,
                                                                                                                column=0,
                                                                                                                columnspan=2,
                                                                                                                padx=10,
                                                                                                                pady=10)

    Label(restaurant3_page, text="Leros Restaurant", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(restaurant3_page,
          text="If you love Greek vibes and national dishes \nserved at the beach shores. Leros is the best deal.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(restaurant3_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/e81nhMHmCq6HQkDq9").grid(
        row=2, column=0, padx=10, pady=10)
    Button(restaurant3_page, text="Go back to Restaurants main page",
           command=lambda: show_specific_page(restaurant3_page, Restaurants_page_frame), bg="light green").grid(row=3,
                                                                                                                column=0,
                                                                                                                columnspan=2,
                                                                                                                padx=10,
                                                                                                                pady=10)

    ############     parks      ##########
    Parks_page_frame = Frame(root)
    park1 = Button(Parks_page_frame, text="Loopagoon Water Park",
                   command=lambda: show_specific_page(Parks_page_frame, park1_page))
    park2 = Button(Parks_page_frame, text="Prince Naif Public Park",
                   command=lambda: show_specific_page(Parks_page_frame, park2_page))
    park1.pack(side=LEFT, padx=10, pady=200)
    park2.pack(side=LEFT, padx=10, pady=200)

    park1_page = Frame(root)
    park2_page = Frame(root)

    Label(park1_page, text="Loopagoon Water Park", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(park1_page,
          text="Loopagoon offers Ladies unforgettable experience \nwith the water slides at the privet water park!").grid(
        row=1, column=0, padx=10, pady=10)
    Label(park1_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/E8KFZzFEgkmhYZaW6").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(park1_page, text="Go back to Parks main page",
           command=lambda: show_specific_page(park1_page, Parks_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    Label(park2_page, text="Prince Naif Public Park", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(park2_page,
          text="Welcome to Zilal, an Al-Turki community initiative \nwith the Eastern Province Municipality to create a \npositive, human-centered environment.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(park2_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/ZdgGvscV6WSHoM5d9").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(park2_page, text="Go back to Parks main page",
           command=lambda: show_specific_page(park2_page, Parks_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    #############     malls     ############
    Malls_page_frame = Frame(root)
    mall1 = Button(Malls_page_frame, text="Dhahran Mall",
                   command=lambda: show_specific_page(Malls_page_frame, mall1_page))
    mall2 = Button(Malls_page_frame, text="Ithra", command=lambda: show_specific_page(Malls_page_frame, mall2_page))
    mall3 = Button(Malls_page_frame, text="Expo", command=lambda: show_specific_page(Malls_page_frame, mall3_page))
    mall1.pack(side=LEFT, padx=10, pady=200)
    mall2.pack(side=LEFT, padx=10, pady=200)
    mall3.pack(side=LEFT, padx=10, pady=200)

    mall1_page = Frame(root)
    mall2_page = Frame(root)
    mall3_page = Frame(root)

    Label(mall1_page, text="Dhahran Mall", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(mall1_page,
          text="Dhahran is the Dharant city signature that groups \nalot of the major brands and restaurants.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(mall1_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/LNAvyxpRvfz3Ks1GA").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(mall1_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall1_page, Malls_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    Label(mall2_page, text="Ithra", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(mall2_page,
          text="Ithra is a cultural landmark in Dhahran, offering \ndiverse educational and cultural programs.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(mall2_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/AX1ncTrw4fnNcSkx8").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(mall2_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall2_page, Malls_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    Label(mall3_page, text="Expo", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(mall3_page,
          text="Expo Dhahran is a leading venue for international and \nlocal exhibitions, trade shows, and conferences.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(mall3_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/efh9S1YZUXrSvqru5").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(mall3_page, text="Go back to Malls main page",
           command=lambda: show_specific_page(mall3_page, Malls_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                    columnspan=2,
                                                                                                    padx=10, pady=10)

    ############      cafes      ##############
    Cafe_page_frame = Frame(root)
    cafe1 = Button(Cafe_page_frame, text="Al Seef Cafe",
                   command=lambda: show_specific_page(Cafe_page_frame, cafe1_page))
    cafe2 = Button(Cafe_page_frame, text="8oz Cafe", command=lambda: show_specific_page(Cafe_page_frame, cafe2_page))
    cafe3 = Button(Cafe_page_frame, text="Coffee Bean & Tea Leaf Cafe",
                   command=lambda: show_specific_page(Cafe_page_frame, cafe3_page))
    cafe1.pack(side=LEFT, padx=10, pady=200)
    cafe2.pack(side=LEFT, padx=10, pady=200)
    cafe3.pack(side=LEFT, padx=10, pady=200)

    cafe1_page = Frame(root)
    cafe2_page = Frame(root)
    cafe3_page = Frame(root)

    Label(cafe1_page, text="Al Seef Cafe", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(cafe1_page,
          text="For a delightful experience blending elegant ambiance and \ndelicious dishes, Al Seef Cafe is the perfect retreat.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(cafe1_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/ex7g5rfkv4c57vQW6").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(cafe1_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe1_page, Cafe_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                   columnspan=2,
                                                                                                   padx=10, pady=10)

    Label(cafe2_page, text="8oz Cafe", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(cafe2_page,
          text="If you're a coffee lover seeking premium brews and \na cozy atmosphere, Cafe 8oz is your perfect spot.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(cafe2_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/GxfQAzEa7G6ok74e6").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(cafe2_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe2_page, Cafe_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                   columnspan=2,
                                                                                                   padx=10, pady=10)

    Label(cafe3_page, text="Coffee Bean & Tea Leaf Cafe", font=("Times", 25)).grid(row=0, column=1, padx=10, pady=50)
    Label(cafe3_page,
          text="From America to Dhahran. Coffee and tea in a welcoming \nenvironment. Coffee Bean is your go-to destination.").grid(
        row=1, column=0, padx=10, pady=10)
    Label(cafe3_page, text="Here is the rating for the place: \nhttps://maps.app.goo.gl/dB3rvH1HKtwoK7A88").grid(row=2,
                                                                                                                 column=0,
                                                                                                                 padx=10,
                                                                                                                 pady=10)
    Button(cafe3_page, text="Go back to Cafes main page",
           command=lambda: show_specific_page(cafe3_page, Cafe_page_frame), bg="light green").grid(row=3, column=0,
                                                                                                   columnspan=2,
                                                                                                   padx=10, pady=10)

    ################################          go back buttons   ##################

    button_back = Button(Restaurants_page_frame, text="Back", command=go_back_to_homePage, bg="light green")
    button_back.pack(side=LEFT, padx=10, pady=200)

    button_back = Button(Parks_page_frame, text="Back", command=go_back_to_homePage, bg="light green")
    button_back.pack(side=LEFT, padx=10, pady=200)

    button_back = Button(Malls_page_frame, text="Back", command=go_back_to_homePage, bg="light green")
    button_back.pack(side=LEFT, padx=10, pady=200)

    button_back = Button(Cafe_page_frame, text="Back", command=go_back_to_homePage, bg="light green")
    button_back.pack(side=LEFT, padx=10, pady=200)
    # launch the application
    root.mainloop()
homescreen.mainloop()
# this was made by students :
# joud mahmoud al motawa 2250003695
#faimah hadi albahrani   2250000126
#fajer jaber alshowikat  2250001935
#farah khalid balobaid   2250001426
#yara  safwan albukhari  2250003909